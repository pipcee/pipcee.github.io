# ICPC LaTeX Template · v0.9

A compact 25-page contest notebook skeleton.

## Files
- `main.tex` — document entry
- `code/style.tex` — code listing style
- `sections/graph.tex` — sample section
- `README.md`

## Build

```bash
xelatex main.tex
xelatex main.tex
```

Use XeLaTeX for CJK support. Replace the sample section files before printing.
