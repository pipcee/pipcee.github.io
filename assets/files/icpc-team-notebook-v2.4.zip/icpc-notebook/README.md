# ICPC Team Notebook · v2.4

一份轻量的 C++17 竞赛代码模板，适合打印或直接放进比赛仓库。

## 目录
- `template.cpp` — 基础头文件、常用宏、快速读入
- `graph/dinic.cpp` — Dinic 最大流
- `graph/tarjan.cpp` — 有向图强连通分量
- `math/modint.cpp` — 取模整数
- `string/hash.cpp` — 双哈希字符串

## 编译
```bash
g++ -std=c++17 -O2 -Wall -Wextra template.cpp -o main
```

## 使用约定
1. 按题目需要只保留对应的模板，减少编译时间。
2. 多组数据时显式清空全局数组。
3. 涉及 long long 的地方先确认上界。
4. 最后提交前重新跑一遍样例。
