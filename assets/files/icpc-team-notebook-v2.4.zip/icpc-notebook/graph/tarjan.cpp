#include <bits/stdc++.h>
using namespace std;

struct SCC {
    vector<vector<int>> g;
    vector<int> dfn, low, stk, comp;
    vector<char> inStack;
    int timer = 0, top = 0, components = 0;

    explicit SCC(int n) : g(n), dfn(n), low(n), stk(n + 1), comp(n), inStack(n) {}

    void addEdge(int u, int v) { g[u].push_back(v); }

    void dfs(int u) {
        dfn[u] = low[u] = ++timer;
        stk[++top] = u;
        inStack[u] = true;
        for (int v : g[u]) {
            if (!dfn[v]) {
                dfs(v);
                low[u] = min(low[u], low[v]);
            } else if (inStack[v]) {
                low[u] = min(low[u], dfn[v]);
            }
        }
        if (low[u] == dfn[u]) {
            ++components;
            int v;
            do {
                v = stk[top--];
                inStack[v] = false;
                comp[v] = components;
            } while (v != u);
        }
    }

    void build() {
        for (int u = 0; u < (int)g.size(); ++u) {
            if (!dfn[u]) dfs(u);
        }
    }
};
