#include <bits/stdc++.h>
using namespace std;

template <int MOD>
struct ModInt {
    int value;
    ModInt(long long v = 0) : value(int(v % MOD + MOD) % MOD) {}

    ModInt operator+(const ModInt &o) const { return ModInt(value + o.value); }
    ModInt operator-(const ModInt &o) const { return ModInt(value - o.value); }
    ModInt operator*(const ModInt &o) const { return ModInt(1LL * value * o.value); }

    ModInt power(long long exp) const {
        ModInt base = *this, result = 1;
        while (exp > 0) {
            if (exp & 1) result = result * base;
            base = base * base;
            exp >>= 1;
        }
        return result;
    }

    ModInt inverse() const { return power(MOD - 2); }
};
