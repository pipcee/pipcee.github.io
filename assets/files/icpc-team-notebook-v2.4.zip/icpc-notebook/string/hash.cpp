#include <bits/stdc++.h>
using namespace std;

struct DoubleHash {
    static constexpr long long M1 = 1000000007;
    static constexpr long long M2 = 1000000009;
    static constexpr long long B1 = 131;
    static constexpr long long B2 = 137;
    vector<long long> p1, p2, h1, h2;

    explicit DoubleHash(const string &s) {
        int n = (int)s.size();
        p1.assign(n + 1, 1); p2.assign(n + 1, 1);
        h1.assign(n + 1, 0); h2.assign(n + 1, 0);
        for (int i = 0; i < n; ++i) {
            p1[i + 1] = p1[i] * B1 % M1;
            p2[i + 1] = p2[i] * B2 % M2;
            h1[i + 1] = (h1[i] * B1 + s[i]) % M1;
            h2[i + 1] = (h2[i] * B2 + s[i]) % M2;
        }
    }

    pair<long long, long long> get(int l, int r) const {
        long long x = (h1[r] - h1[l - 1] * p1[r - l + 1]) % M1;
        long long y = (h2[r] - h2[l - 1] * p2[r - l + 1]) % M2;
        if (x < 0) x += M1;
        if (y < 0) y += M2;
        return {x, y};
    }
};
