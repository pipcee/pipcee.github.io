#include <bits/stdc++.h>
using namespace std;

using ll = long long;
using pii = pair<int, int>;

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    int n;
    if (!(cin >> n)) return 0;

    vector<ll> a(n);
    for (ll &x : a) cin >> x;

    ll sum = accumulate(a.begin(), a.end(), 0LL);
    cout << sum << "\n";
    return 0;
}
